testing online input upload

PlotR version 23.3.3 .
